public class Lion extends Animal {

    public int topSpeed;
    public Lion(String name, int age, String species, int topSpeed) {
        super(name, age, species);
        this.topSpeed = topSpeed;
    }
}