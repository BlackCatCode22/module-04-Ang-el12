public class Hyena extends Animal {

    public boolean canLaugh;

    public Hyena(String name, int age, String species, boolean canLaugh) {
        super(name, age, species);
        this.canLaugh = canLaugh;
    }


}