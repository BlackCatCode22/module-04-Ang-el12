public class Bear extends Animal {

    public int biteForce;
    public Bear(String name, int age, String species, int biteForce) {
        super(name, age, species);
        this.biteForce = biteForce;
    }


}