public class Tiger extends Animal {

    public boolean largestCat;
    public Tiger(String name, int age, String species, boolean largestCat) {
        super(name, age, species);
        this.largestCat = largestCat;
    }
}